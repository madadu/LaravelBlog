<!DOCTYPE html>
<html dir="rtl" lang="fa">

@include('layouts.admin_header')
        <div class="container-fluid">
            <div class="row">
                <!-- Sidebar Section -->
@include('layouts.admin_sidebar')

                <!-- Main Section -->
                <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 mb-5">
                    <div
                        class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom"
                    >
                        <h1 class="fs-3 fw-bold">ویرایش مقاله</h1>
                    </div>

                    <!-- Posts -->
                    <div class="mt-4">
                        <form class="row g-4"   action="{{route('blogs.update',$blog->id)}}" method="POST" enctype="multipart/form-data">
                            @csrf
                            @method('put')
                            <div class="col-12 col-sm-6 col-md-4">
                                <label class="form-label">عنوان مقاله</label>

                                <input
                                    type="text"
                                    class="form-control"
                                    value="{{$blog->title}}"
                                    name="title"
                                />
                            </div>

                            <div class="col-12 col-sm-6 col-md-4">
                                <label class="form-label">نویسنده مقاله</label>
                                <input
                                    type="text"
                                    class="form-control"
                                    value="{{$blog->author}}"
                                    name="author"
                                />
                            </div>

                            <div class="col-12 col-sm-6 col-md-4">
                                <label class="form-label"
                                    >دسته بندی مقاله</label
                                >
                                
                                <select name="cat_id" class="form-select">
                                <option value="1">انتخاب کنید</option>
                                @foreach($categories as $category)

                                    <option value="{{$category->id}}" @selected($category->id==$blog->cat_id) value="{{$category->id}}">{{$category->title}}</option>

                                @endforeach
                                </select>
                            </div>

                            <div class="col-12 col-sm-6 col-md-4">
                                <label for="formFile" class="form-label"
                                    >تصویر مقاله</label
                                >
                                <input class="form-control" type="file" name="file" />
                            </div>

                            <div class="col-12">
                                <label for="formFile" class="form-label"
                                    >متن مقاله</label
                                >
                                <textarea class="form-control" rows="8">
                                </textarea
                                >
                            </div>

                            <div class="col-12 col-sm-6 col-md-4">
                                <span class="d-block">تصویر مقاله</span>
                                <img class="rounded" src="{{asset('storage/'.$blog->file)}}" width="200" />
                            </div>

                            <div class="col-12">
                                <button type="submit" class="btn btn-dark">
                                    ویرایش
                                </button>
                            </div>
                        </form>
                    </div>
                </main>
            </div>
        </div>

        <script
            src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm"
            crossorigin="anonymous"
        ></script>
    </body>
</html>
