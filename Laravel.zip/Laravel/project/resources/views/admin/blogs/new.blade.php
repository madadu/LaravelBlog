<!DOCTYPE html>
<html dir="rtl" lang="fa">
    @include('layouts.admin_header')
        <div class="container-fluid">
            <div class="row">
                <!-- Sidebar Section -->
            @include('layouts.admin_sidebar')
                <!-- Main Section -->
                <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                    <div
                        class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom"
                    >
                        <h1 class="fs-3 fw-bold">ایجاد مقاله</h1>
                    </div>
                    @if($errors->any())
                            <ul>
                                @foreach($errors->all() as $error)
                                    <li class="text-danger">{{$error}}</li>
                                @endforeach
                            </ul>
                    @endif

                    <!-- Posts -->
                    <div class="mt-4">
                        <form   method="post" id="newBlog"   action="{{route('blogs.store')}}" class="row g-4"   enctype="multipart/form-data">
                            @csrf
                            <div class="col-12 col-sm-6 col-md-4">
                                <label class="form-label">عنوان مقاله</label>
                                    <input type="text" class="form-control @error('title') is-invalid @enderror" name="title"         />
                                <span class="text-danger    d-none" id="title_error"></span>
<!-- 
                            @error('title')
                                <span class="text-danger">{{$message}}</span>
                            @enderror -->
<!-- display errors  -->

                        
                            </div>

                            <div class="col-12 col-sm-6 col-md-4">
                                <label class="form-label">نویسنده مقاله</label>
                                <input type="text" class="form-control"     name="author" />
                                <span class="text-danger    d-none" id="author_error"></span>
                            </div>

                            <div class="col-12 col-sm-6 col-md-4">
                                <label class="form-label"
                                    >دسته بندی مقاله</label
                                >
                                <select name="cat_id" class="form-select">
                                @foreach($categories as $category)
                                    <option value="{{$category->id}}">{{$category->title}}</option>
                                @endforeach
                                </select>
                            </div>

                            <div class="col-12 col-sm-6 col-md-4">
                                <label for="formFile" class="form-label"
                                    >تصویر مقاله</label
                                >
                                <input class="form-control" type="file" name="file" />
                            </div>

                            <div class="col-12">
                                <label for="formFile" class="form-label"
                                    >متن مقاله</label
                                >
                                <textarea
                                    class="form-control"
                                    rows="6"
                                ></textarea>
                            </div>

                            <div class="col-12">
                                <button type="submit" class="btn btn-dark">
                                     ایجاد
                                </button>
                            </div>
                        </form>
                    </div>
                </main>
            </div>
        </div>

        <script
            src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm"
            crossorigin="anonymous"
        ></script>
        <script src="/js/jquery.min.js"></script>
        <script src="/js/test.js"></script>
    </body>
</html>
