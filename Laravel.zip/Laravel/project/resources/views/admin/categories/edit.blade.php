<!DOCTYPE html>
<html dir="rtl" lang="fa">

    @include('layouts.admin_header')
        <div class="container-fluid">
            <div class="row">
                <!-- Sidebar Section -->
                        @include('layouts.admin_sidebar')
                <!-- Main Section -->
                <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                    <div
                        class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom"
                    >
                        <h1 class="fs-3 fw-bold">ایجاد دسته بندی</h1>
                    </div>

                    <!-- Posts -->
                    <div class="mt-4">
                        <form id="newCategory" class="row g-4" method="post"   action="{{route('categories.store')}}">
                            @csrf
                            <div class="col-12 col-sm-6 col-md-4">
                                <label class="form-label">عنوان دسته بندی</label>
                                <input type="text" class="form-control" name="title" value="{{$category->title}}" />
                                <span class="text-danger" id="title_error"></span>

                            @error('title')
                                <span class="text-danger" id="title_error">{{$message}}</span>
                            @enderror
                            </div>

                            <div class="col-12">
                                <button type="submit" class="btn btn-dark">
                                     ایجاد
                                </button>
                            </div>
                        </form>
                    </div>
                </main>
            </div>
        </div>

        <script
            src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm"
            crossorigin="anonymous"
        ></script>

        <script src="/js/jquery.min.js"></script>
        <script src="/js/test.js"></script>

    </body>
</html>
