
            @include('layouts.home_header')
            <main>
                <!-- Content -->
                <section class="mt-4">
                    <div class="row">
                        <!-- Posts & Comments Content -->
                        <div class="col-lg-8">
                            <div class="row justify-content-center">
                                <!-- Post Section -->
                                <div class="col">
                                    <div class="card">
                                        <img
                                            style="width: 300px;"
                                            src="{{asset('storage/'.$post->file)}}"
                                            class="card-img-top"
                                            alt="post-image"
                                        />
                                        <div class="card-body">
                                            <div
                                                class="d-flex justify-content-between"
                                            >
                                                <h5 class="card-title fw-bold">
                                                  {{ $post->title }}
                                                </h5>
                                                <div>
                                                    <span
                                                        class="badge text-bg-secondary"
                                                        >{{$post->category->title}}</span
                                                    >
                                                </div>
                                            </div>
                                            <p
                                                class="card-text text-secondary text-justify pt-3"
                                            >
                                                لورم ایپسوم متن ساختگی با تولید
                                                سادگی نامفهوم از صنعت چاپ و با
                                                استفاده از طراحان گرافیک است.
                                                چاپگرها و متون بلکه روزنامه و
                                                مجله در ستون و سطرآنچنان که لازم
                                                است و برای شرایط فعلی تکنولوژی
                                                مورد نیاز و کاربردهای متنوع با
                                                هدف بهبود ابزارهای کاربردی می
                                                باشد. کتابهای زیادی در شصت و سه
                                                درصد گذشته، حال و آینده شناخت
                                                فراوان جامعه و متخصصان را می
                                                طلبد تا با نرم افزارها شناخت
                                                بیشتری را برای طراحان رایانه ای
                                                علی الخصوص طراحان خلاقی و فرهنگ
                                                پیشرو در زبان فارسی ایجاد کرد.
                                                در این صورت می توان امید داشت که
                                                تمام و دشواری موجود در ارائه
                                                راهکارها و شرایط سخت تایپ به
                                                پایان رسد وزمان مورد نیاز شامل
                                                حروفچینی دستاوردهای اصلی و
                                                جوابگوی سوالات پیوسته اهل دنیای
                                                موجود طراحی اساسا مورد استفاده
                                                قرار گیرد.لورم ایپسوم متن ساختگی
                                                با تولید سادگی نامفهوم از صنعت
                                                چاپ و با استفاده از طراحان
                                                گرافیک است. چاپگرها و متون بلکه
                                                روزنامه و مجله در ستون و
                                                سطرآنچنان که لازم است و برای
                                                شرایط فعلی تکنولوژی مورد نیاز و
                                                کاربردهای متنوع با هدف بهبود
                                                ابزارهای کاربردی می باشد.
                                                کتابهای زیادی در شصت و سه درصد
                                                گذشته، حال و آینده شناخت فراوان
                                                جامعه و متخصصان را می طلبد تا با
                                                نرم افزارها شناخت بیشتری را برای
                                                طراحان رایانه ای علی الخصوص
                                                طراحان خلاقی و فرهنگ پیشرو در
                                                زبان فارسی ایجاد کرد. در این
                                                صورت می توان امید داشت که تمام و
                                                دشواری موجود در ارائه راهکارها و
                                                شرایط سخت تایپ به پایان رسد
                                                وزمان مورد نیاز شامل حروفچینی
                                                دستاوردهای اصلی و جوابگوی سوالات
                                                پیوسته اهل دنیای موجود طراحی
                                                اساسا مورد استفاده قرار گیرد.هدف
                                                بهبود
                                            </p>
                                            <div>
                                                <p class="fs-6 mt-5 mb-0">
                                                    نویسنده :  {{$post->author}}
                                                </p>
                                            </div>
                                        <div class="d-flex  justify-content-between">
                                            <div class="postView">
                                                <i class="icon icon-eye-open "></i> 
                                                    <p id="result"  style="color:#000" class="d-inline">{{$post->view}}</p>
                                            </div>
                                   
                                            <div class="postLike">
                                                <p id="like_counter"  style="color:#000" class="d-inline">{{$post->likes}}</p>
                                                    <i class="icon icon-heart icon-large d-none  "></i> 

                                            @if($like_status)
                                                <i class="icon icon-heart icon-large  "></i> 
                                            @else
                                                <i class="icon icon-heart-empty icon-large" data-id="{{$post->id}}"></i>
                                            @endif
                                            </div>
                                        </div>


                                        </div>
                                    </div>
                                </div>

                                <hr class="mt-4" />

                                <!-- Comment Section -->
                                <div class="col">
                                    <!-- Comment Form -->
                                    <div class="card">
                                        <div class="card-body">
                                            <p class="fw-bold fs-5">
                                                ارسال کامنت
                                            </p>

                                            <form id="postComment" method="post" action="{{route('home.comment',$post->id)}}">
                                                @csrf
                                                <div class="mb-3">
                                                    <label class="form-label"
                                                        >نام</label
                                                    >
                                                    <input
                                                        type="text"
                                                        class="form-control"
                                                        name="user_name"

                                                    />
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label"
                                                        >متن کامنت</label
                                                    >
                                                    <textarea
                                                        class="form-control"
                                                        rows="3"
                                                        name="comment"
                                                    ></textarea>
                                                </div>
                                                <button
                                                    type="submit"
                                                    class="btn btn-dark"
                                                >
                                                    ارسال
                                                </button>
                                            </form>
                                        </div>
                                    </div>

                                    <hr class="mt-4" />
                                    <!-- Comment Content -->
                                    <p class="fw-bold fs-6">تعداد کامنت :{{count($comments)}}</p>
                        @if(count($comments))
                          @foreach($comments as $comment)
                                    <div class="card bg-light-subtle mb-3">
                                        <div class="card-body">
                                            <div
                                                class="d-flex align-items-center"
                                            >
                                                <img
                                                    src="{{asset('storage/uploads/profile.png')}}"
                                                    width="45"
                                                    height="45"
                                                    alt="user-profle"
                                                />

                                                <h5
                                                    class="card-title me-2 mb-0"
                                                >
                                                    {{$comment->user_name}}
                                                </h5>
                                            </div>

                                            <p class="card-text pt-3 pr-3">
                                                    {{$comment->comment}}
                                            </p>
                                        </div>
                                    </div>
                            @endforeach 
                        @endif
                                </div>
                            </div>
                        </div>

                <!-- Sidebar Section -->
                @include('layouts.home_sidebar')
                    </div>
                </section>
            </main>

            <!-- Footer -->
            <footer class="text-center pt-4 my-md-5 pt-md-5 border-top">
                <div class="row flex-column">
                    <div>
                        <p class="">
                            کلیه حقوق محتوا این سایت متعلق به وب سایت webprog.io
                            میباشد
                        </p>
                    </div>
                    <div>
                        <a href="#"
                            ><i
                                class="bi bi-telegram fs-3 text-secondary ms-2"
                            ></i
                        ></a>
                        <a href="#"
                            ><i
                                class="bi bi-whatsapp fs-3 text-secondary ms-2"
                            ></i
                        ></a>
                        <a href="#"
                            ><i class="bi bi-instagram fs-3 text-secondary"></i
                        ></a>
                    </div>
                </div>
            </footer>
        </div>
        <script
            src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm"
            crossorigin="anonymous"
        ></script>



        <script src="/js/jquery.min.js"></script>
        <script>
    $(document).ready(function(){


    // #------------like or dislike

        $('.icon-heart-empty').on('click',function(){
            // get post_id

                target=$(this)
                id=target.data('id')
                // url="/blogs/like/"+id
            $.ajax({
                url:'{{route("home.like",$post->id)}}',
                type:'post',
                data:{
                    _token:'{{csrf_token()}}'
                },
                success:function(json){
                    alert('thank you!!')

                    $('#like_counter').html(json.like)
                    target.addClass('d-none')
                    $('.icon-heart').removeClass('d-none')
                }
            })  // end ajax
        })



        
    // #---- postComment
        $('#postComment').submit(function(e){

        var user_name=$('input[name=user_name]').val().trim()
        var comment=$('textarea[name=comment]').val().trim()

        // validate inputs before send to server
        if(user_name.length<3){
            $('input[name=user_name]').addClass('is-invalid')
            return false
        }

        if(comment.length<10){
            $('textarea[name=comment]').addClass('is-invalid')
            return false
        }

    // get formData and send by ajax

        // e.preventDefault();
        data= $(this).serialize()
        $.ajax({
            url:'{{route("home.comment",$post->id)}}',
            type:'post',
            data:data,
            success:function(json){
                if(json.stat){
                    alert(' message was successfully sent')
                    $('#postComment').html('<p class="alert alert-success">پیغام با موفقیت اِرسال شد</p>')
                }
            }
        })
        return false
        })


    
    })  // end document.ready


        </script>
        <!-- <script src="/js/test.js"></script> -->
    </body>
</html>
