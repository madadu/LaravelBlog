<!DOCTYPE html>
<html dir="rtl" lang="fa">
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>php tutorial || blog project || webprog.io</title>


        <link rel="stylesheet" href="/css/style.css" />
        <link rel="stylesheet" href="{{asset('css/bootstrap.min.css')}}">
    </head>

    <body>
                
        <div class="container py-3">
            <div class="container shadow-sm mb-2" style="direction: ltr; ">
                <nav class="navbar navbar-expand-md  ">

                    <a href="{{route('login')}}" class="nav-link">
                        ورود/ثبت نام
                    </a>
                

                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" >
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse" tabindex="-1" id="navbarSupportedContent" style="direction:rtl">
                        <ul class="navbar-nav ms-auto p-0" >
                            <li class="nav-item">
                                <a href="{{route('home.blogs')}}" class="nav-link">
                                    خانه
                                </a>
                            </li>
                        @if(count($categories))
                            @foreach($categories as $category)
                            <li class="nav-item">
                                <a href="{{route('home.category',$category->title)}}" class="nav-link">
                                    {{$category->title}}
                                </a>
                            </li>
                            @endforeach
                        @endif

                        </ul>
                    </div>
                </nav>        
            </div>
