$(document).ready(function(){

    $('#newBlog').on('submit',function(e){
        // e.preventDefault();
        // empty error field
        $('#title_error').html('')
        $('#author_error').html('')
        // get inputs
        title=$('input[name=title]').val()
        author=$('input[name=author]').val()
        // validation
        let error=0
        if(title.trim().length==0){
            $('#title_error').removeClass('d-none').html('پرکردن این فیلد اِلزامی اَست ')
            return false    
        }
        if(author.trim().length==0){
            $('#author_error').removeClass('d-none').html('پرکردن این فیلد اِلزامی اَست ')
            return false
        }
    // if everything 's ok do submit
        if(error==0)
            alert('doing submit ??')

})


// #-----------------------categories

    $('#newCategory').on('submit',function(e){
        // e.preventDefault();
        var title=$('input[name=title]')
        if(title.val().length<5){
            title.addClass('is-invalid')
            $('#title_error').html('عنوان دسته بندی صحیح نمی باشد')
            return false

        }
        return true

    })




    
// #--------------like or dislike
         // like or dislike
    // refer to single.blade






// #------------------ post comment

    // refer to single.blade.php

// function Welcome(){
//     $.toast({
//         heading: 'Welcome to Company ',
//         text: 'view, edit and upload new posts to keep your users engaged.',
//         position: 'top-right',
//         loaderBg: '#ff6849',
//         icon: 'info',
//         hideAfter: 3700,
//         stack: 6
//     })
// }

// Welcome();





}) // end $(document).ready
