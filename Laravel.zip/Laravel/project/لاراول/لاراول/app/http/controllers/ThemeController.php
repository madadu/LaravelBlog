<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\blogs;
use App\Models\category;
use App\Models\Comments;
use App\Models\usersLike;
use App\Models\UsersViews;
use FFI\Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;

// ------------------------ Eloquent ORM


// # get post/s

// $posts=blogs::all();     // get all
// $post=blogs::find($id);  // get  by  id
// $blog=blogs::findorFail($id);    



//  # create new one
    // 1. create method
// usersLike::create(
//     ['ip_address'=>$request->ip(),'blog_id'=>$id]
// );

    // 2.   new object 

// $obj=new usersLike(
//     ['ip_address'=>$request->ip(),'blog_id'=>$id]
// );
// $obj->save();


// # update row
    // 1. update
    $blog->update([
        'title'=>$request->get('title'),
        'author'=>$request->author,
        'file'=>$path
    ]);

    // 2  with save() method
        // $blog->title=$request->title;
        // $blog->author=$request->author;
        // $blog->save();


// #  where or where   
//    1.(OR)    $blogs=blogs::where('title','like',%search%)->orwhere('author','like',%search%)->get()


// 2.(AND)     $like_status=usersLike::where('ip','=',$request->ip())->where('blog_id','=',$id)->get();
//         $Comments=Comments::where('post_id','=',$id)->where('stat','=',0)->get();


//  # join tables   
//          $posts=blogs::join('category as a','blogs.cat_id','=','a.id')->where('a.title',$category)->get('blogs.*');

// ---->methods  instead of get()  {exists(),count(),max(),min(),average(),....)






// #---------------------------------- validation

// $translate_errors=['search.required'=>'لطفا مقدار صحیح وارد کنید','search.min'=>'حداقل مقدار ورودی 4 کاراکتر می باشد'];

// $request->validate(['title'=>'unique:categories],$errors);   // store same name was forbidden
// $request->validate(['search'=>'required|min:4'],$translate_errors); required fields    && minimum required character







// #------------------------------ Files 

    // # uploade file 
        // file will be saved in storage/app/public/uploads  OR  storage/app/private/uploads(default)
        $path=$request->file('file')->store('uploads','public'); 
    
    // # delete uploaded file 
        // @1   File Facade
        $path=public_path('storage/'.$blog->file); //==> E:\razavi\project\ecommerce\public\storage/uploads/iRsV2ds5PqBXsKYfKAXvOW3Lt1lyV3R8O8DSS47B.jpg
        File::delete($path);    // true on success 

        // @2   storage Facade
        // Storage::delete($blog->file);    //delete from local disk (storage/app/public/...)
        Storage::disk('public')->delete($blog->file);   // delete from public disk (storage/app/public/...)










class themeController
{
    /**
     * diaplay all posts .
     */
    public function index(){
        $posts=blogs::all();
        $categories=category::all();
            return view('home/index',compact('posts','categories'));
    }

// search in Blogs
    public function searchInBlogs(Request $request){
    // first validate 
        $translate_errors=['search.required'=>'لطفا مقدار صحیح وارد کنید','search.min'=>'حداقل مقدار ورودی 4 کاراکتر می باشد'];
        $request->validate(['search'=>'required|min:4'],$translate_errors);

    // filter 
        $search=$request->search;
        $blogs=blogs::where('author','like',"%{$search}%")->orWhere('title','like',"%{$search}%")->get();
        $categories=category::all();
            return(view('home.search',['posts'=>$blogs,'categories'=>$categories]));
    }


// fileter posts by_category
    public function filter_By_Category($category){
        // dd($id);
        $categories=category::all();
        $posts=blogs::join('category as a','blogs.cat_id','=','a.id')->where('a.title',$category)->get('blogs.*');
        // print_r($posts);
            return view('home.category',['posts'=>$posts,'categories'=>$categories]);
    }





// ---------------------------# single

    
    /**
     * display each post (single page).
     */
    public function show(string $id,Request $request){
        // get post by id
            $post=blogs::find($id);
        // get categories
            $categories=category::all();
        // get post_comments
            $Comments=Comments::where('blog_id','=',$id)->where('stat','=',1)->get();
        // page views   
            $page_view=UsersViews::where('blog_id',$id)->where('ip_address',$request->ip())->exists();
            if(!$page_view){
                UsersViews::create([
                    'ip_address'=>$request->ip(),
                    'blog_id'=>$id
                ]);
                $post->view++;
                $post->save();
            }
            
        // post like
            $like_status=usersLike::where('ip_address','=',$request->ip())->where('blog_id','=',$id)->exists();

                return view('home/single',['post'=>$post,'comments'=>$Comments,'like_status'=>$like_status,'categories'=>$categories]);
        }



    /**
     * save comments .
     */
    public function store(Request $request,$id){

        Comments::create([
            'user_name'=>$request->user_name,
            'comment'=>$request->comment,
            'blog_id'=>$id
        ]
        );
        return response()->json(['stat'=>1]);
    }


// like post 
    public function like($id,Request $request) {
        $post=blogs::find($id);
    // save user_ip address to prevent one more time likes
        usersLike::create(
            ['ip_address'=>$request->ip(),'blog_id'=>$id]
        );

    // like ++
            $post->likes++;
            $res=$post->save();

    // user return number of likes 
            return Response()->json(['like'=>$post->likes]);
    }





    // 
}
