<?php

// php artisan make:model -m    **create model and its migration

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class blogs extends Model{


    
    protected $table='posts';   // change model_table

    public $timestamps=false;   // stop saving (created_at,updated_at)fields  in DB

    protected $fillable=['title','author'];     // set useable fields 
}
