<?php 

#0  how to  create new blade
// php artisan make:view	




#1 how to add styles,fonts,js...	4/22/2025

// just take files  in public dir then  use asset func 
// fxp: put admin.css in css  in public)) access with: asset(css/admin.css)




#2      security issue in form(post)
// csrf@   -- take this code in your form (generate random code with expire time)
// .env     -- change expire time 



#3  shortif

//  {{strpos($_SERVER['REQUEST_URI'],'index')?'text-secondary':''}}


#4  if& else

// @if(count($posts))
// 	...
// @else
// 	...

// @endif


#5  include

// @extends('layouts.app')	-- do like @include('layouts/app')


# 6 how to selected category 
// @1  selected each post_category	
// 	@selected($category->id == $post->category_id)
// 	OR
// 	@if($category->id==$blog->cat_id) selected  @endif


?>



<!DOCTYPE html>
<html dir="rtl" lang="fa">
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>php tutorial || blog project || webprog.io</title>

        <link
            rel="stylesheet"
            href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css"
        />
        <link
            href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css"
            rel="stylesheet"
            integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9"
            crossorigin="anonymous"
        />

        <link rel="stylesheet" href="../../assets/css/style.css" />
    </head>

    <body>
        <header
            class="navbar sticky-top bg-secondary flex-md-nowrap p-0 shadow-sm"
        >
            <a
                class="navbar-brand col-md-3 col-lg-2 me-0 px-3 fs-5 text-white"
                href="index.html"
                >پنل ادمین</a
            >

            <button
                class="ms-2 nav-link px-3 text-white d-md-none"
                type="button"
                data-bs-toggle="offcanvas"
                data-bs-target="#sidebarMenu"
            >
                <i class="bi bi-justify-left fs-2"></i>
            </button>
        </header>

        <div class="container-fluid">
            <div class="row">
                <!-- include Sidebar Section	(sidebar located in layouts/admin/sidebar.blade.php) -->
@include('layouts.admin_sidebar')	    	
                <!-- Main Section -->
                <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                    <div
                        class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom"
                    >
                        <h1 class="fs-3 fw-bold">مقالات</h1>

                        <div class="btn-toolbar mb-2 mb-md-0">
                            <a href="{{route('blogs.new')}}" class="btn btn-sm btn-dark">
                                ایجاد مقاله
                            </a>
                        </div>
                    </div>
				<!-- display message  -->
                    @if(session('success'))
                    <div class="alert alert-success text-center">
                        {{session('success')}}
                    </div>
                    @endif

                     <!-- Posts -->
                     <div class="mt-4">
                        <div class="table-responsive small">
                            <table class="table table-hover align-middle">
                                <thead>
                                    <tr>
                                        <th>id</th>
                                        <th>عنوان</th>
                                        <th>نویسنده</th>
                                        <th>عملیات</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    @foreach($posts as $post)
                                    <tr>
                                        <th>{{$post->id}}</th>
                                        <td>{{$post->title}}</td>
                                        <td>{{$post->author}}</td>
                                        <td>
                                            <a
                                                href="{{route('blogs.edit',$post->id)}}"
                                                class="btn btn-sm btn-outline-primary"
                                                >ویرایش</a
                                            >
                                            <a
                                                href="{{route('blogs.delete',$post->id)}}"
                                                class="btn btn-sm  btn-outline-danger"
                                                >حذف</a
                                            >
                                        </td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </main>
            </div>
        </div>

        <script
            src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm"
            crossorigin="anonymous"
        ></script>
    </body>
</html>


<style>
    /* .table-hover>tbody>tr:hover>* {
    --bs-table-color-state: #181414;
    --bs-table-bg-state: rgb(0 182 185 / 8%);
} */
</style>