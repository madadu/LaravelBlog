$(document).ready(function(){

    $('#newBlog').on('submit',function(e){
        // e.preventDefault();
        // empty error field
        $('#title_error').html('')
        $('#author_error').html('')
        // get inputs
        title=$('input[name=title]').val()
        author=$('input[name=author]').val()
        // validation
        let error=0
        if(title.trim().length==0){
            $('#title_error').removeClass('d-none').html('پرکردن این فیلد اِلزامی اَست ')
            return false    
        }
        if(author.trim().length==0){
            $('#author_error').removeClass('d-none').html('پرکردن این فیلد اِلزامی اَست ')
            return false
        }
    // if everything 's ok do submit
        if(error==0)
            alert('doing submit ??')

})



// #--------------like or dislike

    $('.icon-heart-empty').on('click',)


}) // end $(document).ready
