<?php


#0  where to save Database credetials
    // DB_CONNECTION=mysql
    // DB_HOST=127.0.0.1
    // DB_PORT=3306
    // DB_DATABASE=laravel
    // DB_USERNAME=root
    // DB_PASSWORD=
    //  ./env file  in root directory
    

#1   how to   create tables
    // php artisan make:migration blogs     -- just create migration not run
    // php artisan migrate              -- run cammand (create tables in data base)


#2
    // - php artisan migrate:refresh		-- rerun all database migrations(all data will be removed)
    // - php artisan migrate:fresh	-- like above (just first, drop all tables then(like above)



use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration{
    /**
     * Run the migrations.
     */
    public function up(): void{
        Schema::create('blogs', function (Blueprint $table){
            $table->charset('utf8mb4');
            $table->collation('utf8mb4_persian_ci');
            $table->id()->autoIncrement();
            $table->string('title');
            $table->string('author');
    // #----- forign key Constraint

        //1. $table->bigIncrements('id'); // 8->bigint(20) **   
        //2. $table->id();   //  bigIncrement 8->bigint(20) **
        //3. $table->integer('id',true); // increment column int(11) #
    // the 3 c above matched with
            // $table->foreignId('blog_id'); // bigint(20) **
            // $table->integer('blog_id'); //   int(11) #

        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void{
        Schema::dropIfExists('blogs');
    }
};
