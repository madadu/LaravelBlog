<?php

use App\Http\Controllers\blogsController;
use Illuminate\Support\Facades\Route;



// 1.   php artisan route:list	-- display list of routes

Route::get('/', function () {
    return view('welcome');
});

//#--------groupe routes----------------- define admin_pages routes  
Route::group(['prefix'=>'admin'],function(){
    // main page
    Route::get('index',function(){
        return view('admin/index');
    })->name('admin');

    
    //------------## blogs
// @ get 
        // display all 
        Route::get('blogs',[blogsController::class,'index'])->name('blogs');
        // create new post
        Route::get('blogs/new',function(){
            return view('admin/blogs/new');
        })->name('blogs.new');
        // edit post
        Route::get('blogs/edit/{blog}',[blogsController::class,'show'])->name('blogs.edit');
        // delete post
        Route::get('blogs/delete/{id}',[blogsController::class,'destroy'])->name('blogs.delete');
// @ post 
        Route::post('blogs/new',[blogsController::class,'store'])->name('blogs.store');
        
        
});
