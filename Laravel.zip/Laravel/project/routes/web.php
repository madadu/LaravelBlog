<?php

use App\Http\Controllers\blogsController;
use App\Http\Controllers\categoryController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\themeController;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;


Route::get('/', function () {
    return view('welcome');
});





//##------------------------- define admin_pages routes

Route::group(['prefix'=>'admin'],function(){

    //#----blogs
// @ get 

    // main page
            Route::get('dashboard',[blogsController::class,'get_In_dash'])->name('admin');
            Route::get('blogs',[blogsController::class,'index'])->name('blogs');
        // create new post
            Route::get('blogs/new',[blogsController::class,'create'])->name('blogs.new');
            // edit post
            Route::get('blogs/edit/{id}',[blogsController::class,'edit'])->name('blogs.edit');
            // delete post
            Route::get('blogs/delete/{id}',[blogsController::class,'destroy'])->name('blogs.delete');


// @ post 
        Route::post('blogs/new',[blogsController::class,'store'])->name('blogs.store');
        Route::put('/blogs/update/{id}',[blogsController::class,'update'])->name('blogs.update');


    //#----categories

// @ Get
        Route::get('/categories',[categoryController::class,'index'])->name('categories');
        Route::get('/categories/new',[categoryController::class,'create'])->name('categories.new');
        Route::get('/categories/delete/{id}',[categoryController::class,'destroy'])->name('categories.delete');
        Route::get('/categories/edit/{id}',[categoryController::class,'edit'])->name('categories.edit');

// @ Post
        Route::post('/categories/new',[categoryController::class,'store'])->name('categories.store');

    // #_-----comments

        Route::get('/comments',[blogsController::class,'getComments'])->name('comments');
        Route::get('/comments/delete/{id}',[blogsController::class,'deleteComment'])->name('comments.delete');
        Route::get('/comments/Accept/{id}',[blogsController::class,'acceptComment'])->name('comments.accept');

}); 
 // end admin_route-groupes


// ##-------------------define theme routes
// @get 
    // main page
    Route::get('blogs',[themeController::class,'index'])->name('home.blogs');
    //  single page
    Route::get('blogs/{id}',[themeController::class,'show'])->name('home.single');
    // categories
    Route::get('blogs/categories/{category}',[themeController::class,'filter_By_Category'])->name('home.category');

// @post
    // post comment
    Route::post('blogs/{id}/comment/',[themeController::class,'store'])->name('home.comment');
    // like posts 
    Route::post('blogs/like/{id}',[themeController::class,'like'])->name('home.like');
    // search in blogs
    Route::post('blogs/search',[themeController::class,'searchInBlogs'])->name('home.search');




Auth::routes();     // create all required authetication routes

Route::get('/home',[HomeController::class,'index'])->name('home');

