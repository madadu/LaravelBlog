<?php

namespace App\Http\Controllers;

use App\Models\blogs;
use App\Models\Blogs as ModelsBlogs;
use App\Models\category;
use App\Models\Comments;
use App\Models\usersLike;
use App\Models\UsersViews;
use Exception as GlobalException;
use FFI\Exception;
use Illuminate\Http\Client\Response;
use Illuminate\Http\Request;

use function Laravel\Prompts\alert;

class themeController{
    /**
     * diaplay all posts .
     */
    public function index(){
        $posts=blogs::all();
        $categories=category::all();
            return view('home/index',compact('posts','categories'));
    }

// search in Blogs
    public function searchInBlogs(Request $request){
    // first validate 
        $translate_errors=['search.required'=>'لطفا مقدار صحیح وارد کنید','search.min'=>'حداقل مقدار ورودی 4 کاراکتر می باشد'];
        $request->validate(['search'=>'required|min:4'],$translate_errors);

    // filter 
        $search=$request->search;
        $blogs=blogs::where('author','like',"%{$search}%")->orWhere('title','like',"%{$search}%")->get();
        $categories=category::all();
            return(view('home.search',['posts'=>$blogs,'categories'=>$categories]));
    }


// fileter posts by_category
    public function filter_By_Category($category){
        // dd($id);
        $categories=category::all();
        $posts=blogs::join('category as a','blogs.cat_id','=','a.id')->where('a.title',$category)->get('blogs.*');
        // print_r($posts);
            return view('home.category',['posts'=>$posts,'categories'=>$categories]);
    }





// ---------------------------# single

    
    /**
     * display each post (single page).
     */
    public function show(string $id,Request $request){
        // get post by id
            $post=blogs::find($id);
        // get categories
            $categories=category::all();
        // get post_comments
            $Comments=Comments::where('blog_id','=',$id)->where('stat','=',1)->get();
        // page views   
            $page_view=UsersViews::where('blog_id',$id)->where('ip_address',$request->ip())->exists();
            if(!$page_view){
                UsersViews::create([
                    'ip_address'=>$request->ip(),
                    'blog_id'=>$id
                ]);
                $post->view++;
                $post->save();
            }
            
        // post like
            $like_status=usersLike::where('ip_address','=',$request->ip())->where('blog_id','=',$id)->exists();

                return view('home/single',['post'=>$post,'comments'=>$Comments,'like_status'=>$like_status,'categories'=>$categories]);
        }



    /**
     * save comments .
     */
    public function store(Request $request,$id){

            
        Comments::create([
            'user_name'=>$request->user_name,
            'comment'=>$request->comment,
            'blog_id'=>$id
        ]
        );
        return response()->json(['stat'=>1]);
    }


// like post 
    public function like($id,Request $request) {
        $post=blogs::find($id);
    // save user_ip address to prevent one more time likes
        usersLike::create(
            ['ip_address'=>$request->ip(),'blog_id'=>$id]
        );

    // like ++
            $post->likes++;
            $res=$post->save();

    // user return number of likes 
            return Response()->json(['like'=>$post->likes]);
    }





    // 
}
