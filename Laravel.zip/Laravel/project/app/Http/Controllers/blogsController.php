<?php

namespace App\Http\Controllers;


use App\Models\blogs;
use App\Models\category;
use App\Models\Comments;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;

use function PHPUnit\Framework\isNull;

class blogsController extends Controller{


    /**
     * Create a new controller instance.
     *
     * @return void
     * 
     */
    // run before all request in this class to make sure user user is authenticate  5/5/2025


    public function __construct(){

        $this->middleware('auth');
         
    }




    public function get_In_dash (Auth $auth){

        if(!Auth::user()->is_admin){
            $posts=blogs::all();
                return view('admin.blogs.index',compact('posts'));
        }
        $comments=Comments::all();
        $posts=blogs::all();
        $categories=category::all();
                return view('admin/index',compact('posts','categories','comments'));
    }

    /**
     * Display a listing of the resource.
     */
    public function index(){
    // @1
        // $posts=DB::table('blogs')->get();
    // @2
        $posts=blogs::all();
            return view('admin/blogs/index',['posts'=>$posts]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create(){
        $categories=category::all();
            return view('admin/blogs/new',compact('categories'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request){
        // translate  validation_errors
        // translate errors
        $translated_errors=['title.max'=>'حداکثر کاراکتر عنوان 8 می باشد','file.required'=>'فایلی اِنتخاب نشده اَست'];
        // validation rules
        $request->validate(['title'=>'max:20','file'=>'required'],$translated_errors);
    
        // uploade file 
        $path=$request->file('file')->store('uploads','public');  
        // file will be saved in storage/app/public/uploads  OR  storage/app/private/uploads(default)
    
    // # save in DB
        // @1  save() 
            // prepare data
            // $data=[
            //     'title'=>$request->title,   // or $request->get('title')
            //     'author'=>$request->author
            // ];
        // $blog=new blogs($data);
        //     $blog->save();
        // @2   create() 
    
            blogs::create([
                'title'=>$request->title,
                'author'=>$request->author,
                'file'=>$path,
                'cat_id'=>$request->cat_id
            ]);
            // blogs::create($request->all()); OR  $blog->create($request->all())
            // blogs::create($request->all());
    
    //# finally  back with success message
                return redirect(route('blogs'))->with('success','عملیات با موفقیت اَنجام شد');
    }
    
    /**
     * Display the specified resource.
     */

    public function show($id){
        blogs::find($id);

    }





    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id){ 
    // @1   with DB class
        // $blog=DB::table('blogs')->where('id','=',$id)->get()[0];
    // @2 with Model
        $blog=blogs::findorFail($id);
        $categories=category::all();
        return view('admin/blogs/edit',compact('blog','categories'));
    }





    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id){

        $blog=blogs::findorFail($id);
        $path=$blog->file;

    // if user wants to upload new picture
        if(!isNull($request->file('file'))){
        // delete uploaded file
            Storage::disk('public')->delete($blog->file);
        // upload  new file
            $path=$request->file('file')->store('uploads','public');  // arg2 (public or private)  
        }

    // @1 update()
        $blog->update([
            
            'title'=>$request->get('title'),
            'author'=>$request->author,
            'file'=>$path,
            'cat_id'=>$request->cat_id

        ]);

    // @2      with save() method
        // $blog->title=$request->title;
        // $blog->author=$request->author;
        // $blog->save();
        return redirect(route('blogs'))->with('success','عملیات با موفقیت اَنجام شد');
}


    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id){

        $blog=blogs::find($id);
        try{

        // #----------delete uploaded file 
        // @1   File Facade
            $path=public_path('storage/'.$blog->file); //==> E:\razavi\project\ecommerce\public\storage/uploads/iRsV2ds5PqBXsKYfKAXvOW3Lt1lyV3R8O8DSS47B.jpg
            File::delete($path);    // true on success 

        // @2   storage Facade
            // Storage::delete($blog->file);    //delete from local disk (storage/app/public/...)
            Storage::disk('public')->delete($blog->file);   // delete from public disk (storage/app/public/...)

        // #delete from DB
            $blog->delete();           
                return redirect(route('blogs'))->with('success','حذف با موفقیت اَنجام شد');
        // 
        }catch(Exception $exception){
                return redirect(route('blogs'))->with('error',$exception);
        }
    }




    // #_---------------------comments


    public function getComments()  {

        $categories=category::all();
        $comments=Comments::all();
            return view('admin.comments',compact('comments','categories'));
    }

// delete comment by id
    public function deleteComment($id) {
        $comment=Comments::find($id);
        $comment->delete();
            return redirect(route('comments'))->with('success','عملیات با موفقیت اَنجام شد');
    }

// accept comment (make stat=1)
    public function acceptComment($id) {
        $comment=Comments::find($id);
        $comment->stat=1;
        $comment->save();
            return redirect(route('comments'))->with('success','عملیات با موفقیت اَنجام شد ');
    }


}   // end class
