<?php



namespace App\Http;

use Illuminate\Foundation\Http\Kernel as HttpKernel ;

class kernel extends HttpKernel{

    protected $routeMiddleware=['forceReLogin'=>\App\Http\Middleware\forceReLogin::class];
}  

