<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void{
        Schema::create('users_views', function (Blueprint $table){
            // $table->increments('id');// 4->int(10)
            // $table->bigIncrements('id'); // 8->bigint(20) **
            // $table->id();   //  bigIncrement 8->bigint(20) **
            $table->integer('id',true); // increment column int(11) #
            $table->string('ip_address',45)->nullable();
            $table->foreignId('blog_id'); // bigint(20) **
            // $table->integer('blog_id'); //   int(11) #
            $table->foreign('blog_id')->references('id')->on('blogs')->onDelete('cascade');
            $table->charset('utf8mb4');
            $table->collation('utf8mb4_persian_ci');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void{
        Schema::dropIfExists('users_views');
    }
};
