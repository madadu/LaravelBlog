<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void{
        Schema::create('blogs', function (Blueprint $table){

            $table->id();
            $table->string('title');
            $table->string('author');
            $table->string('file',100);
            $table->integer('view')->default(1);
            $table->integer('likes')->default(1);
            $table->foreignId('cat_id');
            // if referenced_column(id) in referenced table(category) was deleted then related posts will be cascade(removed)
            $table->foreign('cat_id')->references('id')->on('category')->onDelete('cascade');
            $table->charset('utf8mb4');
            $table->collation('utf8mb4_persian_ci');
            
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void{
        Schema::dropIfExists('blogs');
    }
};
