<?php

namespace Database\Seeders;

use App\Models\User;
use App\Models\blogs;
use App\Models\category;
// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder{
    /**
     * Seed the application's database.
     */
    public function run(): void{

        User::factory()->create([
            'name' => 'admin',
            'email' => 'admin@example.com',
            'password'=>'madadi123123',
            'is_admin'=>1
        ]);

        // User::factory(10)->create();
//         blogs::factory()->count(10)->create([
//                 'title'=>'title_N_1'
// ]);


    }
}
